/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_thread.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bloisel <bloisel@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/13 16:55:48 by bloisel           #+#    #+#             */
/*   Updated: 2023/07/13 18:37:11 by bloisel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/philo.h"

void init_thread(t_inf *info)
{
	int i;
	pthread_t t[info->nb_philo];
	i = 0;
	while (i < info->nb_philo)
	{
		pthread_create(&t[i] , NULL , thread_routine , info->phiphi[i]);  
		i++;
	}
	i = 0;
	while(i < info->nb_philo)
	{
		pthread_detach(t[i]);
		i++;	
	}
	while (1)
	{
		usleep(200);
		if (info->stop[0] == 1)
			return ;
	// 	// if((check_death(info) == 1))
	// 	// 	return ;
	}
}